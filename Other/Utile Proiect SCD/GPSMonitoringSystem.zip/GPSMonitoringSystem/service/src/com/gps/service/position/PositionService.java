package com.gps.service.position;

/**
 * @author radu.miron
 * @since 10/8/13
 */
public interface PositionService {
    void savePosition(String jsonPosition) throws Exception;
}
