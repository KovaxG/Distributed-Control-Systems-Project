package com.gps.rest.util;

/**
 * @author radu.miron
 * @since 11/14/13
 */
public class WsConstants {
    public static final String SUCCESS_STATUS = "{\"statusCode\":0, \"statusText\":\"SUCCESS\"}";
    public static final String FAIL_STATUS ="{\"statusCode\":1, \"status\":\"FAIL\"}";
}
